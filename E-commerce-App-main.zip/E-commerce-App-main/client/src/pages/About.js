import React from 'react'
import Layout from '../components/Layout/Layout'
import aboutUs from '../components/images/about.jpeg'
const About = () => {
  return (
    <Layout title={"About Us- Ecommerce App"}>
        <div className='contact-row'>
            <img src={aboutUs} alt='contactus_logo'></img>
          <div className='contact-row-col-2'>
          <p>llllll lll lll </p>
            
            </div>
          </div>
    </Layout>
  )
}

export default About